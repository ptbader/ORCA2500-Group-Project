#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  1 08:06:16 2025

@author: valeriyabondarenko
"""

import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt
import seaborn as sns

# aesthetic purposes
sns.set_theme(style="darkgrid", context="talk")

# CSV file, ready to use
flights = pd.read_csv("/Users/valeriyabondarenko/flights/FinalSustainabilityDataset.csv")

# filter NYC airports
nyc_airports = ["JFK", "LGA", "EWR"]
flights = flights[flights["ORIGIN"].isin(nyc_airports)]

# remove cancelled flights
flights = flights[flights["CANCELLED"] == 0]

# on-time indicator
flights["on_time"] = (flights["ARR_DELAY"] <= 15).astype(int)

# long haul indicator
flights["long_haul"] = (flights["DISTANCE"] > 1500).astype(int)

# sustainability metrics
# fuel per seat-km (already provided)
flights["fuel_per_seat_km"] = flights["Fuel Consumption, SAR (kg/km/seat)"]
# scale fuel efficiency to grams per seat-km
flights["fuel_per_seat_km_g"] = flights["fuel_per_seat_km"] * 1000  # kg → g


# fuel burn per passenger
flights["fuel_per_pax"] = flights["TOTAL FUEL CONSUMPTION KG"] / flights["Total Pax"].replace(0, np.nan)

# premium seating ratio
flights["premium_ratio"] = (
    (flights["Premium Economy"] + flights["Business"] + flights["First"]) / flights["Total Pax"].replace(0, np.nan)
)

# CO2 estimate
flights["co2_kg"] = flights["TOTAL FUEL CONSUMPTION KG"] * 3.16


# clean airline names
flights["AIRLINE_NAME_CLEAN"] = (
    flights["AIRLINE_NAME"]
    .str.split(":").str[0]
    .str.replace(r"(Airlines|Air Lines|Inc\.|Co\.)", "", regex=True)
    .str.strip()
)

# graphs!

# boxplot: fuel efficiency vs on-time performance
flights["on_time_cat"] = flights["on_time"].map({0: "No", 1: "Yes"}) #need to do this for the graph aesthetics because without it 
#won't be able to seperate the colours for yes and no, this transforms the column into a category that makes it seperate yes and no

plt.figure(figsize=(10,5))
sns.boxplot(
    data=flights,
    x="AIRLINE_NAME_CLEAN",
    y="fuel_per_seat_km_g",
    hue="on_time_cat",  # now categorical
    palette={"Yes": "#66c2a5", "No": "#c21807"},
    showfliers=False
)
plt.title("Fuel Efficiency by Airline and Punctuality", weight="bold", fontfamily="Times New Roman")
plt.xlabel("Airline", fontfamily="Times New Roman")
plt.xticks(rotation=45, fontsize=8, fontfamily="Times New Roman")
plt.ylabel("Fuel per Seat-Km (g)", fontfamily="Times New Roman")
plt.yticks(fontsize=8, fontfamily="Times New Roman")
plt.legend(title="On-time Flight")
plt.tight_layout()
plt.show()


# heatmap: mean fuel efficiency for on-time flights by airline and distance
pivot = flights[flights["on_time"] == 1].pivot_table(
    values="fuel_per_seat_km_g",
    index="AIRLINE_NAME_CLEAN",
    columns="long_haul",
    aggfunc="mean"
)

plt.figure(figsize=(8,6))
sns.heatmap(
    pivot,
    annot=True,
    fmt=".2f",
    cmap="crest",
    linewidths=0.4,
    linecolor="white",
    cbar_kws={"shrink": 0.75}
)
plt.title("Mean Fuel Efficiency for On-Time Flights by Airline and Distance",
          fontsize=14, weight="bold", fontfamily="Times New Roman")
plt.xlabel("Short Haul (0) / Long Haul (1)", fontsize=12, fontfamily="Times New Roman")
plt.ylabel("Airline", fontsize=12, fontfamily="Times New Roman")
plt.xticks(fontsize=10, fontfamily="Times New Roman")
plt.yticks(fontsize=10, fontfamily="Times New Roman")
plt.tight_layout()
plt.show()














